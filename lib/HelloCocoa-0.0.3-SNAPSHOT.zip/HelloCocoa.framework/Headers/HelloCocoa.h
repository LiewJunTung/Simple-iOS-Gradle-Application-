//
//  HelloCocoa.h
//  HelloCocoa
//
//  Created by Jun Tung Liew on 30/1/18.
//  Copyright © 2018 JT. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for HelloCocoa.
FOUNDATION_EXPORT double HelloCocoaVersionNumber;

//! Project version string for HelloCocoa.
FOUNDATION_EXPORT const unsigned char HelloCocoaVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HelloCocoa/PublicHeader.h>


